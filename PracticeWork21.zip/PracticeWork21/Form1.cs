﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PracticeWork21
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Задаём начальную сортировку
            cbSortRazdel1.SelectedIndex = 0;
            cbSortRazdel2.SelectedIndex = 0;

            // Для отладки
            lbRazdel1.Items.AddRange(new object[] { "Слово 1", "Слово 2", "Слово 3", "Слово 4" });
            lbRazdel2.Items.AddRange(new object[] { "Слово 5", "Слово 6", "Слово 7", "Слово 8" });

            lbRazdel2.Update();
            lbRazdel1.Update();
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void выходAltxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            var file = openFileDialog1.OpenFile();
            var read = new StreamReader(file);

            rtbFileText.Text = read.ReadToEnd();

            read.Close();
        }

        private void MenuOpen_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            var write = new StreamWriter(saveFileDialog1.FileName);

            for (int i = 0; i < lbRazdel2.Items.Count; i++)
            {
                write.WriteLine((string)lbRazdel2.Items[i]);
            }

            write.Close();
        }

        private void spravkaClick(object sender, EventArgs e)
        {
            MessageBox.Show("Будет дополнено...", "Информация о приложении и разработчике");
        }

        private void btnMoveToLeft_Click(object sender, EventArgs e)
        {
            lbRazdel1.Items.Add(lbRazdel2.SelectedItem);
            lbRazdel2.Items.Remove(lbRazdel2.SelectedItem);
        }

        private void btnMoveToRight_Click(object sender, EventArgs e)
        {
            lbRazdel2.Items.Add(lbRazdel1.SelectedItem);
            lbRazdel1.Items.Remove(lbRazdel1.SelectedItem);
        }

        private void btnMoveAllToLeft_Click(object sender, EventArgs e)
        {
            lbRazdel1.Items.AddRange(lbRazdel2.Items);
            lbRazdel2.Items.Clear();
        }

        private void btnMoveAllToRight_Click(object sender, EventArgs e)
        {
            lbRazdel2.Items.AddRange(lbRazdel1.Items);
            lbRazdel1.Items.Clear();
        }

        private void btnCleartRazdel2_Click(object sender, EventArgs e)
        {
            lbRazdel2.Items.Clear();
            lbRazdel2.Update();
        }

        private void btnClearRazdel1_Click(object sender, EventArgs e)
        {
            lbRazdel1.Items.Clear();
            lbRazdel1.Update();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Вы действительно хотите выйти?", "Подтвердите действие", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

            if (result == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form2 AddDialog = new Form2();
            AddDialog.Owner = this;
            AddDialog.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {


            DeleteSelectedStrings(lbRazdel1);
            DeleteSelectedStrings(lbRazdel2);

        }

        private void DeleteSelectedStrings(ListBox listBox)
        {
            for (int i = listBox.Items.Count - 1; i >= 0; i--)
            {
                if (listBox.GetSelected(i)) listBox.Items.RemoveAt(i);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lbRazdel1.Items.Clear();
            lbRazdel2.Items.Clear();
            lbSearch.Items.Clear();

            tbSearch.Text = string.Empty;

            rbSelectAll.Checked = true;

            rtbFileText.Clear();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {

            lbRazdel1.Items.Clear();
            lbRazdel2.Items.Clear();

            lbRazdel1.BeginUpdate();

            string[] Strings = rtbFileText.Text.Split(new char[] { '\n', '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string s in Strings)
            {
                var stringStr = s.Trim();
                if (stringStr == String.Empty) continue;


                if (rbSelectAll.Checked)
                {
                    lbRazdel1.Items.Add(stringStr);
                }

                else if (rbSelectContainsNums.Checked)
                {
                    if (Regex.IsMatch(stringStr, @"\d")) lbRazdel1.Items.Add(stringStr);

                   
                }

                else if (rbSelectContainsEmail.Checked)
                {
                    if (Regex.IsMatch(stringStr, @"\w+@\w+\.\w+")) lbRazdel1.Items.Add(stringStr);
                }
            }

            lbRazdel1.EndUpdate();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            lbSearch.Items.Clear();
            string Find = tbSearch.Text;

            if (checkRazdel1.Checked)
            {
                foreach (string String in lbRazdel1.Items)
                {
                    if (String.Contains(Find)) lbSearch.Items.Add(String);
                }
            }

            if (checkRazdel2.Checked)
            {
                foreach (string String in lbRazdel2.Items)
                {
                    if (String.Contains(Find)) lbSearch.Items.Add(String);
                }
            }
        }
               

        private void btnSortRazdel1_Click(object sender, EventArgs e)
        {
            if (cbSortRazdel1.SelectedIndex == 0)
            {
        
            }
            else if (cbSortRazdel1.SelectedIndex == 1)
            {

            }
            else if (cbSortRazdel1.SelectedIndex == 2)
            {

            }
            else if (cbSortRazdel1.SelectedIndex == 4)
            {

            }
        }


        private void btnSortRazdel2_Click(object sender, EventArgs e)
        {


            if (cbSortRazdel2.SelectedIndex == 0)
            {
                lbRazdel2.Sorted = false;

                List<object> buff = new List<object> { };

                foreach (object item in lbRazdel2.Items)
                {
                    buff.Add(item);
                }

                buff.Sort((a, b) => a.ToString().Length.CompareTo(b.ToString().Length));

                lbRazdel2.Items.Clear();
                lbRazdel2.Items.AddRange(buff.ToArray());

                lbRazdel2.Update();
            }
            else if (cbSortRazdel2.SelectedIndex == 1)
            {
                lbRazdel2.Sorted = false;

                List<object> buff = new List<object> { };

                foreach (object item in lbRazdel2.Items)
                {
                    buff.Add(item);
                }

                buff.Sort((b, a) => a.ToString().Length.CompareTo(b.ToString().Length));

                lbRazdel2.Items.Clear();
                lbRazdel2.Items.AddRange(buff.ToArray());

                lbRazdel2.Update();
            }
            else if (cbSortRazdel2.SelectedIndex == 2)
            {
                lbRazdel2.Sorted = true;
                lbRazdel2.Update();
            }
            else if (cbSortRazdel2.SelectedIndex == 3)
            {
                lbRazdel2.Sorted = false;

                List<object> buff = new List<object> { };

                foreach (object item in lbRazdel2.Items)
                {
                    buff.Add(item);
                }

                buff.Reverse();

                lbRazdel2.Items.Clear();
                lbRazdel2.Items.AddRange(buff.ToArray());

                lbRazdel2.Update();
            }
        }
    }
}
