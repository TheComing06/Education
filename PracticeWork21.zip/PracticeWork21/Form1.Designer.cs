﻿namespace PracticeWork21
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.rtbFileText = new System.Windows.Forms.RichTextBox();
            this.gbSelectWords = new System.Windows.Forms.GroupBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.rbSelectContainsEmail = new System.Windows.Forms.RadioButton();
            this.rbSelectContainsNums = new System.Windows.Forms.RadioButton();
            this.rbSelectAll = new System.Windows.Forms.RadioButton();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbSearch = new System.Windows.Forms.GroupBox();
            this.checkRazdel2 = new System.Windows.Forms.CheckBox();
            this.checkRazdel1 = new System.Windows.Forms.CheckBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lbSearch = new System.Windows.Forms.ListBox();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.lblEnterWord = new System.Windows.Forms.Label();
            this.btnCleartRazdel2 = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClearRazdel1 = new System.Windows.Forms.Button();
            this.btnSortRazdel2 = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSortRazdel1 = new System.Windows.Forms.Button();
            this.lbRazdel2 = new System.Windows.Forms.ListBox();
            this.lbRazdel1 = new System.Windows.Forms.ListBox();
            this.btnMoveAllToLeft = new System.Windows.Forms.Button();
            this.btnMoveAllToRight = new System.Windows.Forms.Button();
            this.btnMoveToLeft = new System.Windows.Forms.Button();
            this.btnMoveToRight = new System.Windows.Forms.Button();
            this.cbSortRazdel2 = new System.Windows.Forms.ComboBox();
            this.cbSortRazdel1 = new System.Windows.Forms.ComboBox();
            this.lblRazdel2 = new System.Windows.Forms.Label();
            this.lblRazel1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Menu = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSave = new System.Windows.Forms.ToolStripMenuItem();
            this.выходAltxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolSparvka = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel1.SuspendLayout();
            this.gbSelectWords.SuspendLayout();
            this.gbSearch.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.rtbFileText);
            this.panel1.Controls.Add(this.gbSelectWords);
            this.panel1.Controls.Add(this.btnReset);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.gbSearch);
            this.panel1.Controls.Add(this.btnCleartRazdel2);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.btnClearRazdel1);
            this.panel1.Controls.Add(this.btnSortRazdel2);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSortRazdel1);
            this.panel1.Controls.Add(this.lbRazdel2);
            this.panel1.Controls.Add(this.lbRazdel1);
            this.panel1.Controls.Add(this.btnMoveAllToLeft);
            this.panel1.Controls.Add(this.btnMoveAllToRight);
            this.panel1.Controls.Add(this.btnMoveToLeft);
            this.panel1.Controls.Add(this.btnMoveToRight);
            this.panel1.Controls.Add(this.cbSortRazdel2);
            this.panel1.Controls.Add(this.cbSortRazdel1);
            this.panel1.Controls.Add(this.lblRazdel2);
            this.panel1.Controls.Add(this.lblRazel1);
            this.panel1.Location = new System.Drawing.Point(13, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(775, 503);
            this.panel1.TabIndex = 0;
            // 
            // rtbFileText
            // 
            this.rtbFileText.Location = new System.Drawing.Point(471, 20);
            this.rtbFileText.Name = "rtbFileText";
            this.rtbFileText.ReadOnly = true;
            this.rtbFileText.Size = new System.Drawing.Size(291, 474);
            this.rtbFileText.TabIndex = 20;
            this.rtbFileText.Text = "";
            // 
            // gbSelectWords
            // 
            this.gbSelectWords.Controls.Add(this.btnStart);
            this.gbSelectWords.Controls.Add(this.rbSelectContainsEmail);
            this.gbSelectWords.Controls.Add(this.rbSelectContainsNums);
            this.gbSelectWords.Controls.Add(this.rbSelectAll);
            this.gbSelectWords.Location = new System.Drawing.Point(248, 290);
            this.gbSelectWords.Name = "gbSelectWords";
            this.gbSelectWords.Size = new System.Drawing.Size(200, 100);
            this.gbSelectWords.TabIndex = 19;
            this.gbSelectWords.TabStop = false;
            this.gbSelectWords.Text = "Выбор слов";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(141, 16);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(53, 78);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Начать";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // rbSelectContainsEmail
            // 
            this.rbSelectContainsEmail.AutoSize = true;
            this.rbSelectContainsEmail.Location = new System.Drawing.Point(7, 66);
            this.rbSelectContainsEmail.Name = "rbSelectContainsEmail";
            this.rbSelectContainsEmail.Size = new System.Drawing.Size(118, 17);
            this.rbSelectContainsEmail.TabIndex = 2;
            this.rbSelectContainsEmail.TabStop = true;
            this.rbSelectContainsEmail.Text = "Содержащие email";
            this.rbSelectContainsEmail.UseVisualStyleBackColor = true;
            // 
            // rbSelectContainsNums
            // 
            this.rbSelectContainsNums.AutoSize = true;
            this.rbSelectContainsNums.Location = new System.Drawing.Point(7, 43);
            this.rbSelectContainsNums.Name = "rbSelectContainsNums";
            this.rbSelectContainsNums.Size = new System.Drawing.Size(128, 17);
            this.rbSelectContainsNums.TabIndex = 1;
            this.rbSelectContainsNums.TabStop = true;
            this.rbSelectContainsNums.Text = "Содержащие цифры";
            this.rbSelectContainsNums.UseVisualStyleBackColor = true;
            // 
            // rbSelectAll
            // 
            this.rbSelectAll.AutoSize = true;
            this.rbSelectAll.Checked = true;
            this.rbSelectAll.Location = new System.Drawing.Point(7, 20);
            this.rbSelectAll.Name = "rbSelectAll";
            this.rbSelectAll.Size = new System.Drawing.Size(44, 17);
            this.rbSelectAll.TabIndex = 0;
            this.rbSelectAll.TabStop = true;
            this.rbSelectAll.Text = "Все";
            this.rbSelectAll.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(248, 396);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(200, 39);
            this.btnReset.TabIndex = 18;
            this.btnReset.Text = "Сброс";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(248, 449);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(200, 45);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // gbSearch
            // 
            this.gbSearch.Controls.Add(this.checkRazdel2);
            this.gbSearch.Controls.Add(this.checkRazdel1);
            this.gbSearch.Controls.Add(this.btnSearch);
            this.gbSearch.Controls.Add(this.lbSearch);
            this.gbSearch.Controls.Add(this.tbSearch);
            this.gbSearch.Controls.Add(this.lblEnterWord);
            this.gbSearch.Location = new System.Drawing.Point(7, 290);
            this.gbSearch.Name = "gbSearch";
            this.gbSearch.Size = new System.Drawing.Size(225, 204);
            this.gbSearch.TabIndex = 16;
            this.gbSearch.TabStop = false;
            this.gbSearch.Text = "Поиск";
            // 
            // checkRazdel2
            // 
            this.checkRazdel2.AutoSize = true;
            this.checkRazdel2.Location = new System.Drawing.Point(135, 126);
            this.checkRazdel2.Name = "checkRazdel2";
            this.checkRazdel2.Size = new System.Drawing.Size(72, 17);
            this.checkRazdel2.TabIndex = 22;
            this.checkRazdel2.Text = "Раздел 2";
            this.checkRazdel2.UseVisualStyleBackColor = true;
            // 
            // checkRazdel1
            // 
            this.checkRazdel1.AutoSize = true;
            this.checkRazdel1.Location = new System.Drawing.Point(135, 103);
            this.checkRazdel1.Name = "checkRazdel1";
            this.checkRazdel1.Size = new System.Drawing.Size(72, 17);
            this.checkRazdel1.TabIndex = 21;
            this.checkRazdel1.Text = "Раздел 1";
            this.checkRazdel1.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(135, 151);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(80, 43);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Поиск";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lbSearch
            // 
            this.lbSearch.FormattingEnabled = true;
            this.lbSearch.Location = new System.Drawing.Point(9, 60);
            this.lbSearch.Name = "lbSearch";
            this.lbSearch.Size = new System.Drawing.Size(120, 134);
            this.lbSearch.TabIndex = 19;
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(9, 33);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(120, 20);
            this.tbSearch.TabIndex = 18;
            // 
            // lblEnterWord
            // 
            this.lblEnterWord.AutoSize = true;
            this.lblEnterWord.Location = new System.Drawing.Point(6, 16);
            this.lblEnterWord.Name = "lblEnterWord";
            this.lblEnterWord.Size = new System.Drawing.Size(129, 13);
            this.lblEnterWord.TabIndex = 17;
            this.lblEnterWord.Text = "Введите искомое слово";
            // 
            // btnCleartRazdel2
            // 
            this.btnCleartRazdel2.Location = new System.Drawing.Point(321, 242);
            this.btnCleartRazdel2.Name = "btnCleartRazdel2";
            this.btnCleartRazdel2.Size = new System.Drawing.Size(121, 23);
            this.btnCleartRazdel2.TabIndex = 15;
            this.btnCleartRazdel2.Text = "Очистить";
            this.btnCleartRazdel2.UseVisualStyleBackColor = true;
            this.btnCleartRazdel2.Click += new System.EventHandler(this.btnCleartRazdel2_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(152, 242);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(147, 23);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClearRazdel1
            // 
            this.btnClearRazdel1.Location = new System.Drawing.Point(7, 242);
            this.btnClearRazdel1.Name = "btnClearRazdel1";
            this.btnClearRazdel1.Size = new System.Drawing.Size(120, 23);
            this.btnClearRazdel1.TabIndex = 13;
            this.btnClearRazdel1.Text = "Очистить";
            this.btnClearRazdel1.UseVisualStyleBackColor = true;
            this.btnClearRazdel1.Click += new System.EventHandler(this.btnClearRazdel1_Click);
            // 
            // btnSortRazdel2
            // 
            this.btnSortRazdel2.Location = new System.Drawing.Point(321, 213);
            this.btnSortRazdel2.Name = "btnSortRazdel2";
            this.btnSortRazdel2.Size = new System.Drawing.Size(121, 23);
            this.btnSortRazdel2.TabIndex = 12;
            this.btnSortRazdel2.Text = "Сортировка";
            this.btnSortRazdel2.UseVisualStyleBackColor = true;
            this.btnSortRazdel2.Click += new System.EventHandler(this.btnSortRazdel2_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(152, 213);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAdd.Size = new System.Drawing.Size(147, 23);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSortRazdel1
            // 
            this.btnSortRazdel1.Location = new System.Drawing.Point(7, 213);
            this.btnSortRazdel1.Name = "btnSortRazdel1";
            this.btnSortRazdel1.Size = new System.Drawing.Size(120, 23);
            this.btnSortRazdel1.TabIndex = 10;
            this.btnSortRazdel1.Text = "Сортировка";
            this.btnSortRazdel1.UseVisualStyleBackColor = true;
            this.btnSortRazdel1.Click += new System.EventHandler(this.btnSortRazdel1_Click);
            // 
            // lbRazdel2
            // 
            this.lbRazdel2.FormattingEnabled = true;
            this.lbRazdel2.Location = new System.Drawing.Point(321, 47);
            this.lbRazdel2.Name = "lbRazdel2";
            this.lbRazdel2.Size = new System.Drawing.Size(121, 160);
            this.lbRazdel2.TabIndex = 9;
            // 
            // lbRazdel1
            // 
            this.lbRazdel1.FormattingEnabled = true;
            this.lbRazdel1.Location = new System.Drawing.Point(7, 47);
            this.lbRazdel1.Name = "lbRazdel1";
            this.lbRazdel1.Size = new System.Drawing.Size(120, 160);
            this.lbRazdel1.TabIndex = 8;
            // 
            // btnMoveAllToLeft
            // 
            this.btnMoveAllToLeft.Location = new System.Drawing.Point(147, 125);
            this.btnMoveAllToLeft.Name = "btnMoveAllToLeft";
            this.btnMoveAllToLeft.Size = new System.Drawing.Size(75, 23);
            this.btnMoveAllToLeft.TabIndex = 7;
            this.btnMoveAllToLeft.Text = "<<-";
            this.btnMoveAllToLeft.UseVisualStyleBackColor = true;
            this.btnMoveAllToLeft.Click += new System.EventHandler(this.btnMoveAllToLeft_Click);
            // 
            // btnMoveAllToRight
            // 
            this.btnMoveAllToRight.Location = new System.Drawing.Point(224, 125);
            this.btnMoveAllToRight.Name = "btnMoveAllToRight";
            this.btnMoveAllToRight.Size = new System.Drawing.Size(75, 23);
            this.btnMoveAllToRight.TabIndex = 6;
            this.btnMoveAllToRight.Text = "->>";
            this.btnMoveAllToRight.UseVisualStyleBackColor = true;
            this.btnMoveAllToRight.Click += new System.EventHandler(this.btnMoveAllToRight_Click);
            // 
            // btnMoveToLeft
            // 
            this.btnMoveToLeft.Location = new System.Drawing.Point(147, 96);
            this.btnMoveToLeft.Name = "btnMoveToLeft";
            this.btnMoveToLeft.Size = new System.Drawing.Size(75, 23);
            this.btnMoveToLeft.TabIndex = 5;
            this.btnMoveToLeft.Text = "<--";
            this.btnMoveToLeft.UseVisualStyleBackColor = true;
            this.btnMoveToLeft.Click += new System.EventHandler(this.btnMoveToLeft_Click);
            // 
            // btnMoveToRight
            // 
            this.btnMoveToRight.Location = new System.Drawing.Point(224, 96);
            this.btnMoveToRight.Name = "btnMoveToRight";
            this.btnMoveToRight.Size = new System.Drawing.Size(75, 23);
            this.btnMoveToRight.TabIndex = 4;
            this.btnMoveToRight.Text = "--->";
            this.btnMoveToRight.UseVisualStyleBackColor = true;
            this.btnMoveToRight.Click += new System.EventHandler(this.btnMoveToRight_Click);
            // 
            // cbSortRazdel2
            // 
            this.cbSortRazdel2.FormattingEnabled = true;
            this.cbSortRazdel2.Items.AddRange(new object[] {
            "Сортировка по длине (возр.)",
            "Сортировка по длине (убыв.)",
            "Сортировка по алфавиту (возр.)",
            "Сортировка по алфавиту (убыв.)"});
            this.cbSortRazdel2.Location = new System.Drawing.Point(321, 20);
            this.cbSortRazdel2.Name = "cbSortRazdel2";
            this.cbSortRazdel2.Size = new System.Drawing.Size(121, 21);
            this.cbSortRazdel2.TabIndex = 3;
            this.cbSortRazdel2.Text = "Сортировка по...";
            // 
            // cbSortRazdel1
            // 
            this.cbSortRazdel1.FormattingEnabled = true;
            this.cbSortRazdel1.Items.AddRange(new object[] {
            "Сортировка по длине (возр.)",
            "Сортировка по длине (убыв.)",
            "Сортировка по алфавиту (возр.)",
            "Сортировка по алфавиту (убыв.)"});
            this.cbSortRazdel1.Location = new System.Drawing.Point(7, 20);
            this.cbSortRazdel1.Name = "cbSortRazdel1";
            this.cbSortRazdel1.Size = new System.Drawing.Size(121, 21);
            this.cbSortRazdel1.TabIndex = 2;
            this.cbSortRazdel1.Text = "Сортировка по...";
            // 
            // lblRazdel2
            // 
            this.lblRazdel2.AutoSize = true;
            this.lblRazdel2.Location = new System.Drawing.Point(318, 4);
            this.lblRazdel2.Name = "lblRazdel2";
            this.lblRazdel2.Size = new System.Drawing.Size(53, 13);
            this.lblRazdel2.TabIndex = 1;
            this.lblRazdel2.Text = "Раздел 2";
            // 
            // lblRazel1
            // 
            this.lblRazel1.AutoSize = true;
            this.lblRazel1.Location = new System.Drawing.Point(4, 4);
            this.lblRazel1.Name = "lblRazel1";
            this.lblRazel1.Size = new System.Drawing.Size(53, 13);
            this.lblRazel1.TabIndex = 0;
            this.lblRazel1.Text = "Раздел 1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu,
            this.toolSparvka});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Menu
            // 
            this.Menu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuOpen,
            this.menuSave,
            this.выходAltxToolStripMenuItem});
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(48, 20);
            this.Menu.Text = "Файл";
            // 
            // MenuOpen
            // 
            this.MenuOpen.Name = "MenuOpen";
            this.MenuOpen.Size = new System.Drawing.Size(180, 22);
            this.MenuOpen.Text = "Открыть Ctrl+O";
            this.MenuOpen.Click += new System.EventHandler(this.MenuOpen_Click);
            // 
            // menuSave
            // 
            this.menuSave.Name = "menuSave";
            this.menuSave.Size = new System.Drawing.Size(180, 22);
            this.menuSave.Text = "Сохранить Ctrl+S";
            this.menuSave.Click += new System.EventHandler(this.сохранитьToolStripMenuItem_Click);
            // 
            // выходAltxToolStripMenuItem
            // 
            this.выходAltxToolStripMenuItem.Name = "выходAltxToolStripMenuItem";
            this.выходAltxToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.выходAltxToolStripMenuItem.Text = "Выход Alt+x";
            this.выходAltxToolStripMenuItem.Click += new System.EventHandler(this.выходAltxToolStripMenuItem_Click);
            // 
            // toolSparvka
            // 
            this.toolSparvka.Name = "toolSparvka";
            this.toolSparvka.Size = new System.Drawing.Size(24, 20);
            this.toolSparvka.Text = "?";
            this.toolSparvka.Click += new System.EventHandler(this.spravkaClick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            this.openFileDialog1.Title = "Выберите файл...";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "txt";
            this.saveFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 536);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbSelectWords.ResumeLayout(false);
            this.gbSelectWords.PerformLayout();
            this.gbSearch.ResumeLayout(false);
            this.gbSearch.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Menu;
        private System.Windows.Forms.Label lblRazdel2;
        private System.Windows.Forms.Label lblRazel1;
        private System.Windows.Forms.ToolStripMenuItem MenuOpen;
        private System.Windows.Forms.ToolStripMenuItem menuSave;
        private System.Windows.Forms.ToolStripMenuItem toolSparvka;
        public System.Windows.Forms.ListBox lbRazdel2;
        public System.Windows.Forms.ListBox lbRazdel1;
        private System.Windows.Forms.Button btnMoveAllToLeft;
        private System.Windows.Forms.Button btnMoveAllToRight;
        private System.Windows.Forms.Button btnMoveToLeft;
        private System.Windows.Forms.Button btnMoveToRight;
        private System.Windows.Forms.ComboBox cbSortRazdel2;
        private System.Windows.Forms.ComboBox cbSortRazdel1;
        private System.Windows.Forms.GroupBox gbSearch;
        private System.Windows.Forms.Label lblEnterWord;
        private System.Windows.Forms.Button btnCleartRazdel2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClearRazdel1;
        private System.Windows.Forms.Button btnSortRazdel2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSortRazdel1;
        private System.Windows.Forms.GroupBox gbSelectWords;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.CheckBox checkRazdel2;
        private System.Windows.Forms.CheckBox checkRazdel1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox lbSearch;
        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.RichTextBox rtbFileText;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.RadioButton rbSelectContainsEmail;
        private System.Windows.Forms.RadioButton rbSelectContainsNums;
        private System.Windows.Forms.RadioButton rbSelectAll;
        private System.Windows.Forms.ToolStripMenuItem выходAltxToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

