﻿namespace PracticeWork21
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbAddText = new System.Windows.Forms.GroupBox();
            this.rbRazdel1 = new System.Windows.Forms.RadioButton();
            this.rbRazdel2 = new System.Windows.Forms.RadioButton();
            this.tbTextInput = new System.Windows.Forms.TextBox();
            this.lblTextInput = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbAddText.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbAddText
            // 
            this.gbAddText.Controls.Add(this.rbRazdel2);
            this.gbAddText.Controls.Add(this.rbRazdel1);
            this.gbAddText.Location = new System.Drawing.Point(13, 13);
            this.gbAddText.Name = "gbAddText";
            this.gbAddText.Size = new System.Drawing.Size(200, 70);
            this.gbAddText.TabIndex = 0;
            this.gbAddText.TabStop = false;
            this.gbAddText.Text = "Добавить в...";
            // 
            // rbRazdel1
            // 
            this.rbRazdel1.AutoSize = true;
            this.rbRazdel1.Location = new System.Drawing.Point(7, 20);
            this.rbRazdel1.Name = "rbRazdel1";
            this.rbRazdel1.Size = new System.Drawing.Size(71, 17);
            this.rbRazdel1.TabIndex = 0;
            this.rbRazdel1.TabStop = true;
            this.rbRazdel1.Text = "Раздел 1";
            this.rbRazdel1.UseVisualStyleBackColor = true;
            // 
            // rbRazdel2
            // 
            this.rbRazdel2.AutoSize = true;
            this.rbRazdel2.Location = new System.Drawing.Point(7, 44);
            this.rbRazdel2.Name = "rbRazdel2";
            this.rbRazdel2.Size = new System.Drawing.Size(71, 17);
            this.rbRazdel2.TabIndex = 1;
            this.rbRazdel2.TabStop = true;
            this.rbRazdel2.Text = "Раздел 2";
            this.rbRazdel2.UseVisualStyleBackColor = true;
            // 
            // tbTextInput
            // 
            this.tbTextInput.Location = new System.Drawing.Point(12, 111);
            this.tbTextInput.Name = "tbTextInput";
            this.tbTextInput.Size = new System.Drawing.Size(201, 20);
            this.tbTextInput.TabIndex = 1;
            // 
            // lblTextInput
            // 
            this.lblTextInput.AutoSize = true;
            this.lblTextInput.Location = new System.Drawing.Point(12, 95);
            this.lblTextInput.Name = "lblTextInput";
            this.lblTextInput.Size = new System.Drawing.Size(83, 13);
            this.lblTextInput.TabIndex = 2;
            this.lblTextInput.Text = "Введите текст:";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(12, 138);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(95, 23);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(113, 137);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(227, 172);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblTextInput);
            this.Controls.Add(this.tbTextInput);
            this.Controls.Add(this.gbAddText);
            this.Name = "Form2";
            this.Text = "Добавить";
            this.gbAddText.ResumeLayout(false);
            this.gbAddText.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbAddText;
        private System.Windows.Forms.RadioButton rbRazdel2;
        private System.Windows.Forms.RadioButton rbRazdel1;
        private System.Windows.Forms.TextBox tbTextInput;
        private System.Windows.Forms.Label lblTextInput;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
    }
}