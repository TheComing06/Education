﻿namespace LSDB
{
    partial class FormRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.linkAuth = new System.Windows.Forms.LinkLabel();
            this.lblAlrReg = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.tbPassword = new System.Windows.Forms.MaskedTextBox();
            this.tbPhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblAuth = new System.Windows.Forms.Label();
            this.tbRepeatPassword = new System.Windows.Forms.MaskedTextBox();
            this.lbRepeatPassword = new System.Windows.Forms.Label();
            this.cbAccept = new System.Windows.Forms.CheckBox();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.lblPass = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // linkAuth
            // 
            this.linkAuth.AutoSize = true;
            this.linkAuth.Location = new System.Drawing.Point(208, 200);
            this.linkAuth.Name = "linkAuth";
            this.linkAuth.Size = new System.Drawing.Size(90, 13);
            this.linkAuth.TabIndex = 17;
            this.linkAuth.TabStop = true;
            this.linkAuth.Text = "Авторизоваться";
            this.linkAuth.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lblAlrReg
            // 
            this.lblAlrReg.AutoSize = true;
            this.lblAlrReg.Location = new System.Drawing.Point(79, 200);
            this.lblAlrReg.Name = "lblAlrReg";
            this.lblAlrReg.Size = new System.Drawing.Size(134, 13);
            this.lblAlrReg.TabIndex = 16;
            this.lblAlrReg.Text = "Уже зарегистрированы?";
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(12, 170);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(339, 23);
            this.btnRegister.TabIndex = 15;
            this.btnRegister.Text = "Зарегистрироваться";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(109, 93);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.PasswordChar = '•';
            this.tbPassword.Size = new System.Drawing.Size(240, 20);
            this.tbPassword.TabIndex = 14;
            // 
            // tbPhoneNumber
            // 
            this.tbPhoneNumber.Location = new System.Drawing.Point(109, 67);
            this.tbPhoneNumber.Mask = "+7 (999) 000-0000";
            this.tbPhoneNumber.Name = "tbPhoneNumber";
            this.tbPhoneNumber.Size = new System.Drawing.Size(240, 20);
            this.tbPhoneNumber.TabIndex = 13;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(7, 70);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(96, 13);
            this.lblPhone.TabIndex = 11;
            this.lblPhone.Text = "Номер телефона:";
            // 
            // lblAuth
            // 
            this.lblAuth.AutoSize = true;
            this.lblAuth.Location = new System.Drawing.Point(136, 9);
            this.lblAuth.Name = "lblAuth";
            this.lblAuth.Size = new System.Drawing.Size(72, 13);
            this.lblAuth.TabIndex = 10;
            this.lblAuth.Text = "Регистрация";
            // 
            // tbRepeatPassword
            // 
            this.tbRepeatPassword.Location = new System.Drawing.Point(109, 119);
            this.tbRepeatPassword.Name = "tbRepeatPassword";
            this.tbRepeatPassword.PasswordChar = '•';
            this.tbRepeatPassword.Size = new System.Drawing.Size(240, 20);
            this.tbRepeatPassword.TabIndex = 19;
            // 
            // lbRepeatPassword
            // 
            this.lbRepeatPassword.AutoSize = true;
            this.lbRepeatPassword.Location = new System.Drawing.Point(7, 122);
            this.lbRepeatPassword.Name = "lbRepeatPassword";
            this.lbRepeatPassword.Size = new System.Drawing.Size(103, 13);
            this.lbRepeatPassword.TabIndex = 18;
            this.lbRepeatPassword.Text = "Повторите пароль:";
            // 
            // cbAccept
            // 
            this.cbAccept.AutoSize = true;
            this.cbAccept.Location = new System.Drawing.Point(12, 145);
            this.cbAccept.Name = "cbAccept";
            this.cbAccept.Size = new System.Drawing.Size(227, 17);
            this.cbAccept.TabIndex = 20;
            this.cbAccept.Text = "Соглашаюсь с правилами пользования";
            this.cbAccept.UseVisualStyleBackColor = true;
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(109, 41);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(240, 20);
            this.tbLogin.TabIndex = 21;
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.Location = new System.Drawing.Point(7, 96);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(48, 13);
            this.lblPass.TabIndex = 12;
            this.lblPass.Text = "Пароль:";
            this.lblPass.Click += new System.EventHandler(this.lblPass_Click);
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(7, 44);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(41, 13);
            this.lblLogin.TabIndex = 22;
            this.lblLogin.Text = "Логин:";
            // 
            // FormRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 224);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.tbLogin);
            this.Controls.Add(this.cbAccept);
            this.Controls.Add(this.tbRepeatPassword);
            this.Controls.Add(this.lbRepeatPassword);
            this.Controls.Add(this.linkAuth);
            this.Controls.Add(this.lblAlrReg);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.tbPhoneNumber);
            this.Controls.Add(this.lblPass);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblAuth);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "FormRegistration";
            this.Text = "LSDB — Регистрация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkAuth;
        private System.Windows.Forms.Label lblAlrReg;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.MaskedTextBox tbPassword;
        private System.Windows.Forms.MaskedTextBox tbPhoneNumber;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblAuth;
        private System.Windows.Forms.MaskedTextBox tbRepeatPassword;
        private System.Windows.Forms.Label lbRepeatPassword;
        private System.Windows.Forms.CheckBox cbAccept;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.Label lblLogin;
    }
}