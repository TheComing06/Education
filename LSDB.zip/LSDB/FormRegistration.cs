﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSDB
{
    public partial class FormRegistration : Form
    {
        Thread th;

        public FormRegistration()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            th = new Thread(openAuthForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void lblPass_Click(object sender, EventArgs e)
        {

        }

        private void openMainForm(object obj)
        {
            Application.Run(new FormMain());
        }

        private void openAuthForm(object obj)
        {
            Application.Run(new FormAuth());
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                string password = tbPassword.Text;
                string passwordRepeat = tbRepeatPassword.Text;
                string phoneNumber = tbPhoneNumber.Text;
                string login = tbLogin.Text;
                bool check = cbAccept.Checked;

                if (password == "" || passwordRepeat == "" || phoneNumber == "" || login == "")
                {
                    throw new Exception("Введены не все данные.");
                }

                if (password != passwordRepeat)
                {
                    throw new Exception("Ваши пароли не совпадают.");
                }

                if (!check) 
                {
                    throw new Exception("Вам НЕОБХОДИМО согласиться с правилами пользования.");
                }

                SqlConnection conn = new SqlConnection(@"server = 10.137.203.94,1433\SQLEXPRESS; database = leatherStuffDB;  user id = 22.102-21; password = Yflbg2025");
                SqlCommand command = new SqlCommand("SELECT * FROM users WHERE Логин = @Login and Пароль = @password", conn);
                conn.Open();
                command.Parameters.AddWithValue("@login", tbLogin.Text);
                command.Parameters.AddWithValue("@password", tbPassword.Text);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows == true)
                {
                    MessageBox.Show("Данные введены верно!");
                }
                else
                {
                    MessageBox.Show("Проверьте логин и пароль!");
                }

                this.Close();
                th = new Thread(openMainForm);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();

                

            } catch (Exception error)
            {
                MessageBox.Show(error.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
          
        }
    }
}
