﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSDB
{
    public partial class FormAuth : Form
    {
        Thread th;
        public FormAuth()
        {
            InitializeComponent();
        }

        private void openMainForm(object obj)
        {
            Application.Run(new FormMain());
        }

        private void btnAuth_Click(object sender, EventArgs e)
        {
            try
            {
                string login = tbLogin.Text;
                string password = tbPassword.Text;

                if (login == "" || password == "")
                {
                    throw new Exception("Введены не все данные.");
                }
                else
                {
                    SqlConnection conn = new SqlConnection(@"server = 10.137.203.94,1433\SQLEXPRESS; database = leatherStuffDB;  user id = 22.102-21; password = Yflbg2025");
                    SqlCommand command = new SqlCommand("SELECT * FROM users WHERE Логин = @Login and Пароль = @password", conn);
                    conn.Open();
                    command.Parameters.AddWithValue("@login", tbLogin.Text);
                    command.Parameters.AddWithValue("@password", tbPassword.Text);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows == true)
                    {
                        MessageBox.Show("Данные введены верно!");
                    }
                    else
                    {
                        MessageBox.Show("Проверьте логин и пароль!");
                    }
                }
                

                this.Close();
                th = new Thread(openMainForm);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();


            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void opennewform(object obj)
        {
            Application.Run(new FormRegistration());
        }
    }
}
