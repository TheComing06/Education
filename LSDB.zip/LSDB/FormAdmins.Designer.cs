﻿namespace LSDB
{
    partial class FormAdmins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label идентификатор_пользователяLabel;
            System.Windows.Forms.Label все_праваLabel;
            System.Windows.Forms.Label право_добавлятьLabel;
            System.Windows.Forms.Label право_удалятьLabel;
            System.Windows.Forms.Label право_изменятьLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAdmins));
            this.leatherStuffDBDataSet = new LSDB.leatherStuffDBDataSet();
            this.adminsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adminsTableAdapter = new LSDB.leatherStuffDBDataSetTableAdapters.adminsTableAdapter();
            this.tableAdapterManager = new LSDB.leatherStuffDBDataSetTableAdapters.TableAdapterManager();
            this.adminsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.adminsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tbIdentificator = new System.Windows.Forms.TextBox();
            this.cbAll = new System.Windows.Forms.CheckBox();
            this.cbAdd = new System.Windows.Forms.CheckBox();
            this.cbDel = new System.Windows.Forms.CheckBox();
            this.cbEdit = new System.Windows.Forms.CheckBox();
            this.lblLogoAdmin = new System.Windows.Forms.Label();
            идентификатор_пользователяLabel = new System.Windows.Forms.Label();
            все_праваLabel = new System.Windows.Forms.Label();
            право_добавлятьLabel = new System.Windows.Forms.Label();
            право_удалятьLabel = new System.Windows.Forms.Label();
            право_изменятьLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.leatherStuffDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminsBindingNavigator)).BeginInit();
            this.adminsBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // идентификатор_пользователяLabel
            // 
            идентификатор_пользователяLabel.AutoSize = true;
            идентификатор_пользователяLabel.Location = new System.Drawing.Point(13, 86);
            идентификатор_пользователяLabel.Name = "идентификатор_пользователяLabel";
            идентификатор_пользователяLabel.Size = new System.Drawing.Size(164, 13);
            идентификатор_пользователяLabel.TabIndex = 1;
            идентификатор_пользователяLabel.Text = "Идентификатор пользователя:";
            // 
            // все_праваLabel
            // 
            все_праваLabel.AutoSize = true;
            все_праваLabel.Location = new System.Drawing.Point(115, 108);
            все_праваLabel.Name = "все_праваLabel";
            все_праваLabel.Size = new System.Drawing.Size(62, 13);
            все_праваLabel.TabIndex = 3;
            все_праваLabel.Text = "Все права:";
            // 
            // право_добавлятьLabel
            // 
            право_добавлятьLabel.AutoSize = true;
            право_добавлятьLabel.Location = new System.Drawing.Point(79, 131);
            право_добавлятьLabel.Name = "право_добавлятьLabel";
            право_добавлятьLabel.Size = new System.Drawing.Size(98, 13);
            право_добавлятьLabel.TabIndex = 5;
            право_добавлятьLabel.Text = "Право добавлять:";
            // 
            // право_удалятьLabel
            // 
            право_удалятьLabel.AutoSize = true;
            право_удалятьLabel.Location = new System.Drawing.Point(92, 155);
            право_удалятьLabel.Name = "право_удалятьLabel";
            право_удалятьLabel.Size = new System.Drawing.Size(85, 13);
            право_удалятьLabel.TabIndex = 7;
            право_удалятьLabel.Text = "Право удалять:";
            // 
            // право_изменятьLabel
            // 
            право_изменятьLabel.AutoSize = true;
            право_изменятьLabel.Location = new System.Drawing.Point(83, 178);
            право_изменятьLabel.Name = "право_изменятьLabel";
            право_изменятьLabel.Size = new System.Drawing.Size(94, 13);
            право_изменятьLabel.TabIndex = 9;
            право_изменятьLabel.Text = "Право изменять:";
            // 
            // leatherStuffDBDataSet
            // 
            this.leatherStuffDBDataSet.DataSetName = "leatherStuffDBDataSet";
            this.leatherStuffDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // adminsBindingSource
            // 
            this.adminsBindingSource.DataMember = "admins";
            this.adminsBindingSource.DataSource = this.leatherStuffDBDataSet;
            // 
            // adminsTableAdapter
            // 
            this.adminsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.adminsTableAdapter = this.adminsTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.itemsTableAdapter = null;
            this.tableAdapterManager.ordersTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = LSDB.leatherStuffDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.usersTableAdapter = null;
            // 
            // adminsBindingNavigator
            // 
            this.adminsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.adminsBindingNavigator.BindingSource = this.adminsBindingSource;
            this.adminsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.adminsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.adminsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.adminsBindingNavigatorSaveItem});
            this.adminsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.adminsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.adminsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.adminsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.adminsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.adminsBindingNavigator.Name = "adminsBindingNavigator";
            this.adminsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.adminsBindingNavigator.Size = new System.Drawing.Size(323, 25);
            this.adminsBindingNavigator.TabIndex = 0;
            this.adminsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // adminsBindingNavigatorSaveItem
            // 
            this.adminsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.adminsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("adminsBindingNavigatorSaveItem.Image")));
            this.adminsBindingNavigatorSaveItem.Name = "adminsBindingNavigatorSaveItem";
            this.adminsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.adminsBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.adminsBindingNavigatorSaveItem.Click += new System.EventHandler(this.adminsBindingNavigatorSaveItem_Click_2);
            // 
            // tbIdentificator
            // 
            this.tbIdentificator.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.adminsBindingSource, "Идентификатор пользователя", true));
            this.tbIdentificator.Location = new System.Drawing.Point(183, 83);
            this.tbIdentificator.Name = "tbIdentificator";
            this.tbIdentificator.Size = new System.Drawing.Size(100, 20);
            this.tbIdentificator.TabIndex = 2;
            // 
            // cbAll
            // 
            this.cbAll.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.adminsBindingSource, "Все права", true));
            this.cbAll.Location = new System.Drawing.Point(183, 103);
            this.cbAll.Name = "cbAll";
            this.cbAll.Size = new System.Drawing.Size(104, 24);
            this.cbAll.TabIndex = 4;
            this.cbAll.UseVisualStyleBackColor = true;
            // 
            // cbAdd
            // 
            this.cbAdd.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.adminsBindingSource, "Право добавлять", true));
            this.cbAdd.Location = new System.Drawing.Point(183, 126);
            this.cbAdd.Name = "cbAdd";
            this.cbAdd.Size = new System.Drawing.Size(104, 24);
            this.cbAdd.TabIndex = 6;
            this.cbAdd.UseVisualStyleBackColor = true;
            // 
            // cbDel
            // 
            this.cbDel.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.adminsBindingSource, "Право удалять", true));
            this.cbDel.Location = new System.Drawing.Point(183, 150);
            this.cbDel.Name = "cbDel";
            this.cbDel.Size = new System.Drawing.Size(104, 24);
            this.cbDel.TabIndex = 8;
            this.cbDel.UseVisualStyleBackColor = true;
            // 
            // cbEdit
            // 
            this.cbEdit.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.adminsBindingSource, "Право изменять", true));
            this.cbEdit.Location = new System.Drawing.Point(183, 173);
            this.cbEdit.Name = "cbEdit";
            this.cbEdit.Size = new System.Drawing.Size(104, 24);
            this.cbEdit.TabIndex = 10;
            this.cbEdit.UseVisualStyleBackColor = true;
            // 
            // lblLogoAdmin
            // 
            this.lblLogoAdmin.AutoSize = true;
            this.lblLogoAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblLogoAdmin.Location = new System.Drawing.Point(59, 40);
            this.lblLogoAdmin.Name = "lblLogoAdmin";
            this.lblLogoAdmin.Size = new System.Drawing.Size(205, 26);
            this.lblLogoAdmin.TabIndex = 11;
            this.lblLogoAdmin.Text = "Таблица \"Админы\"";
            this.lblLogoAdmin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // FormAdmins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 237);
            this.Controls.Add(this.lblLogoAdmin);
            this.Controls.Add(право_изменятьLabel);
            this.Controls.Add(this.cbEdit);
            this.Controls.Add(право_удалятьLabel);
            this.Controls.Add(this.cbDel);
            this.Controls.Add(право_добавлятьLabel);
            this.Controls.Add(this.cbAdd);
            this.Controls.Add(все_праваLabel);
            this.Controls.Add(this.cbAll);
            this.Controls.Add(идентификатор_пользователяLabel);
            this.Controls.Add(this.tbIdentificator);
            this.Controls.Add(this.adminsBindingNavigator);
            this.Name = "FormAdmins";
            this.Text = "FormAdmins";
            this.Load += new System.EventHandler(this.FormAdmins_Load);
            ((System.ComponentModel.ISupportInitialize)(this.leatherStuffDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminsBindingNavigator)).EndInit();
            this.adminsBindingNavigator.ResumeLayout(false);
            this.adminsBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private leatherStuffDBDataSet leatherStuffDBDataSet;
        private System.Windows.Forms.BindingSource adminsBindingSource;
        private leatherStuffDBDataSetTableAdapters.adminsTableAdapter adminsTableAdapter;
        private leatherStuffDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator adminsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton adminsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox tbIdentificator;
        private System.Windows.Forms.CheckBox cbAll;
        private System.Windows.Forms.CheckBox cbAdd;
        private System.Windows.Forms.CheckBox cbDel;
        private System.Windows.Forms.CheckBox cbEdit;
        private System.Windows.Forms.Label lblLogoAdmin;
    }
}