﻿namespace LSDB
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLogo = new System.Windows.Forms.Label();
            this.btnAdmins = new System.Windows.Forms.Button();
            this.btnItems = new System.Windows.Forms.Button();
            this.btnOrders = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblLogo.Location = new System.Drawing.Point(12, 9);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(244, 26);
            this.lblLogo.TabIndex = 0;
            this.lblLogo.Text = "Leather Stuff Data Base";
            // 
            // btnAdmins
            // 
            this.btnAdmins.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnAdmins.Location = new System.Drawing.Point(65, 48);
            this.btnAdmins.Name = "btnAdmins";
            this.btnAdmins.Size = new System.Drawing.Size(140, 31);
            this.btnAdmins.TabIndex = 1;
            this.btnAdmins.Text = "Админы";
            this.btnAdmins.UseVisualStyleBackColor = true;
            this.btnAdmins.Click += new System.EventHandler(this.btnAdmins_Click);
            // 
            // btnItems
            // 
            this.btnItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnItems.Location = new System.Drawing.Point(65, 85);
            this.btnItems.Name = "btnItems";
            this.btnItems.Size = new System.Drawing.Size(140, 31);
            this.btnItems.TabIndex = 2;
            this.btnItems.Text = "Предметы";
            this.btnItems.UseVisualStyleBackColor = true;
            this.btnItems.Click += new System.EventHandler(this.btnItems_Click);
            // 
            // btnOrders
            // 
            this.btnOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnOrders.Location = new System.Drawing.Point(65, 122);
            this.btnOrders.Name = "btnOrders";
            this.btnOrders.Size = new System.Drawing.Size(140, 31);
            this.btnOrders.TabIndex = 3;
            this.btnOrders.Text = "Заказы";
            this.btnOrders.UseVisualStyleBackColor = true;
            this.btnOrders.Click += new System.EventHandler(this.btnOrders_Click);
            // 
            // btnUsers
            // 
            this.btnUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnUsers.Location = new System.Drawing.Point(65, 159);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(140, 31);
            this.btnUsers.TabIndex = 4;
            this.btnUsers.Text = "Пользователи";
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(273, 236);
            this.Controls.Add(this.btnUsers);
            this.Controls.Add(this.btnOrders);
            this.Controls.Add(this.btnItems);
            this.Controls.Add(this.btnAdmins);
            this.Controls.Add(this.lblLogo);
            this.Name = "FormMain";
            this.Text = "Leather Stuff DB";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Button btnAdmins;
        private System.Windows.Forms.Button btnItems;
        private System.Windows.Forms.Button btnOrders;
        private System.Windows.Forms.Button btnUsers;
    }
}