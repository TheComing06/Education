﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSDB
{
    public partial class FormAdmins : Form
    {
        public FormAdmins()
        {
            InitializeComponent();
        }

        private void adminsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.adminsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.leatherStuffDBDataSet);

        }

        private void FormAdmins_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "leatherStuffDBDataSet.admins". При необходимости она может быть перемещена или удалена.
            this.adminsTableAdapter.Fill(this.leatherStuffDBDataSet.admins);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "leatherStuffDBDataSet.admins". При необходимости она может быть перемещена или удалена.
            this.adminsTableAdapter.Fill(this.leatherStuffDBDataSet.admins);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "leatherStuffDBDataSet.admins". При необходимости она может быть перемещена или удалена.
            this.adminsTableAdapter.Fill(this.leatherStuffDBDataSet.admins);

        }

        private void adminsBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.adminsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.leatherStuffDBDataSet);

        }

        private void adminsBindingNavigatorSaveItem_Click_2(object sender, EventArgs e)
        {
            this.Validate();
            this.adminsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.leatherStuffDBDataSet);

        }

    }
}
