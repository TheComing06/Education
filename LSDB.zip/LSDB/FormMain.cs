﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSDB
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void btnAdmins_Click(object sender, EventArgs e)
        {
            Form formAdmins = new FormAdmins();
            formAdmins.Show();
        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            Form formItems = new FormItems();
            formItems.Show();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            Form formOrders = new FormOrders();
            formOrders.Show();
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            Form formUsers = new FormUsers();
            formUsers.Show();
        }
    }
}
