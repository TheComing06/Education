﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticeWork22
{
    public partial class Form1 : Form
    {
        Rectangle rectangle = new Rectangle(10, 10, 200, 100);
        Rectangle circle = new Rectangle(220, 10, 150, 150);
        Rectangle square = new Rectangle(380, 10, 150, 150);

        bool rectangleClicked = false, circleClicked = false, squareClicked = false;

        int dYrt = 0, dXrt = 0;
        int dYcr = 0, dXcr = 0;
        int dYsq = 0, dXsq = 0;

        int X, Y, dX, dY;
        int LastClicked = 0; 


        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (circleClicked)
            {
                circle.X = e.X - dXcr;
                circle.Y = e.Y - dYcr;

                LastClicked = 2;
            }

            if (squareClicked)
            {
                square.X = e.X - dXsq;
                square.Y = e.Y - dYsq;

                LastClicked = 3;
            }

            if (rectangleClicked)
            {
                rectangle.X = e.X - dXrt;
                rectangle.Y = e.Y - dYrt;

                LastClicked = 1;
            }
            pictureBox1.Invalidate();

            if ((lblView.Location.X < square.X + square.Width) && (lblView.Location.X > square.X))
            {
                if ((lblView.Location.Y < square.Y + square.Height) && (lblView.Location.Y > square.Y))
                {
                    lblInfo.Text = "Синий квадрат";
                }
            }

            if ((lblView.Location.X < circle.X + circle.Width) && (lblView.Location.X > circle.X))
            {
                if ((lblView.Location.Y < circle.Y + circle.Height) && (lblView.Location.Y > circle.Y))
                {
                    lblInfo.Text = "Красный круг";
                }
            }

            if ((lblView.Location.X < rectangle.X + rectangle.Width) && (lblView.Location.X > rectangle.X))
            {
                if ((lblView.Location.Y < rectangle.Y + rectangle.Height) && (lblView.Location.Y > rectangle.Y))
                {
                    lblInfo.Text = "Жёлтый прямоугольник";
                }
            }


        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            rectangleClicked = false;
            circleClicked = false;
            squareClicked = false;

            if (LastClicked == 2)
            {
                if ((lblForm.Location.X < circle.X + circle.Width) && (lblForm.Location.X > circle.X))
                {
                    // Круг -> квадрат

                    if ((lblForm.Location.Y < circle.Y + circle.Height) && (lblForm.Location.Y > circle.Y))
                    {
                        X = circle.X;
                        Y = circle.Y;
                        dX = dYcr;
                        dY = dYcr;
                        circle.X = square.X;
                        circle.Y = square.Y;
                        dXcr = dXsq;
                        dYcr = dYsq;

                        square.X = X;
                        square.Y = Y;
                        dXsq = dX;
                        dYsq = dY;
                    }

                   
                }

                // Круг -> прямоугольник
                if ((lblForm.Location.X < rectangle.X + rectangle.Width) && (lblForm.Location.X > rectangle.X))
                {
                    
                    if ((lblForm.Location.Y < rectangle.Y + rectangle.Height) && (lblForm.Location.Y > rectangle.Y))
                    {
                        X = circle.X;
                        Y = circle.Y;
                        dX = dYcr;
                        dY = dYcr;
                        circle.X = rectangle.X;
                        circle.Y = rectangle.Y;
                        dXcr = dXrt;
                        dYcr = dYrt;

                        rectangle.X = X;
                        rectangle.Y = Y;
                        dXrt = dX;
                        dYrt = dY;
                    }
                }
            }


            if (LastClicked == 1)
            {

                // Прямоугольник -> квадрат
                if ((lblForm.Location.X < square.X + square.Width) && (lblForm.Location.X > square.X))  
                {

                    if ((lblForm.Location.Y < square.Y + square.Height) && (lblForm.Location.Y > square.Y))
                    {
                        X = rectangle.X;
                        Y = rectangle.Y;
                        dX = dYrt;
                        dY = dYrt;
                        rectangle.X = square.X;
                        rectangle.Y = square.Y;
                        dXrt = dXsq;
                        dYrt = dYsq;

                        square.X = X;
                        square.Y = Y;
                        dXsq = dX;
                        dYsq = dY;
                    }
                   
                }

                // Прямоугольник -> круг
                if ((lblForm.Location.X < circle.X + circle.Width) && (lblForm.Location.X > circle.X))
                {      
                    if ((lblForm.Location.Y < circle.Y + circle.Height) && (lblForm.Location.Y > circle.Y))
                    {
                        X = rectangle.X;
                        Y = rectangle.Y;
                        dX = dYrt;
                        dY = dYrt;
                        rectangle.X = circle.X;
                        rectangle.Y = circle.Y;
                        dXrt = dXcr;
                        dYrt = dYcr;

                        circle.X = X;
                        circle.Y = Y;
                        dXcr = dX;
                        dYcr = dY;
                    }
                }
            }


            if (LastClicked == 3)
            {

                // Квадрат -> круг
                if ((lblForm.Location.X < circle.X + circle.Width) && (lblForm.Location.X > circle.X))
                {
                    
                    if ((lblForm.Location.Y < circle.Y + circle.Height) && (lblForm.Location.Y > circle.Y))
                    {

                        X = square.X;
                        Y = square.Y;
                        dX = dYsq;
                        dY = dYsq;
                        square.X = circle.X;
                        square.Y = circle.Y;
                        dXsq = dXcr;
                        dYsq = dYcr;
                        circle.X = X;
                        circle.Y = Y;
                        dXcr = dX;
                        dYcr = dY;
                    }                   
                }

                // Квадрат -> прямоугольник
                if ((lblForm.Location.X < rectangle.X + rectangle.Width) && (lblForm.Location.X > rectangle.X))
                {
                    if ((lblForm.Location.Y < rectangle.Y + rectangle.Height) && (lblForm.Location.Y > rectangle.Y))
                    {

                        X = square.X;
                        Y = square.Y;
                        dX = dYsq;
                        dY = dYsq;
                        square.X = rectangle.X;
                        square.Y = rectangle.Y;
                        dXsq = dXrt;
                        dYsq = dYrt;
                        rectangle.X = X;
                        rectangle.Y = Y;
                        dXrt = dX;
                        dYrt = dY;
                    }
                }
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if ((e.X < rectangle.X + rectangle.Width) && (e.X > rectangle.X))
            {
                if ((e.Y < rectangle.Y + rectangle.Height) && (e.Y > rectangle.Y))
                {
                    rectangleClicked = true;
                    dYrt = e.X - rectangle.X;
                    dYrt = e.Y - rectangle.Y;
                }
            }

            if ((e.X < circle.X + circle.Width) && (e.X > circle.X))
            {
                if ((e.Y < circle.Y + circle.Height) && (e.Y > circle.Y))
                {
                    circleClicked = true;
                    dXcr = e.X - circle.X;
                    dYcr = e.Y - circle.Y;
                }
            }

            if ((e.X < square.X + square.Width) && (e.X > square.X))
            {
                if ((e.Y < square.Y + square.Height) && (e.Y > square.Y))
                {
                    squareClicked = true;
                    dXsq = e.X - square.X;
                    dXsq = e.Y - square.Y;
                }
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Red, circle);
            e.Graphics.FillRectangle(Brushes.Blue, square);
            e.Graphics.FillRectangle(Brushes.Yellow, rectangle);

        }
    }
}
